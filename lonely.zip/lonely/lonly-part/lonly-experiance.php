<?php global $lonly_options;?>	
	<!-- Section: separator -->
    <section id="separator" class="home-section parallax text-center" data-stellar-background-ratio="0.5" style="background: url(
    	
    	<?php
    		if ($lonly_options['separator-parallax-img'] && !empty($lonly_options['separator-parallax-img']['url'])) {
    			echo $lonly_options['separator-parallax-img']['url'];
    		}else {
                echo get_template_directory_uri().'/img/parallax-bg.jpg';
            }
     		
     	?>
     		);">
		<div class="container">
			<div class="row">
					<div class="col-xs-6 col-sm-3 col-md-3">
						<div class="align-center txt-shadow">
							<div class="icon">
								<i class="fa <?php echo $lonly_options['separator1-icon'] ?> fa-5x"></i>
							</div>
						<span class="color-white"><?php echo $lonly_options['separator1-title'] ?></span>
						</div>
					</div>
					<div class="col-xs-6 col-sm-3 col-md-3">
						<div class="align-center txt-shadow">
							<div class="icon">
								<i class="fa <?php echo $lonly_options['separator2-icon'] ?> fa-5x"></i>
							</div>
						<span class="color-white"><?php echo $lonly_options['separator2-title'] ?></span>
						</div>
					</div>
					<div class="col-xs-6 col-sm-3 col-md-3">
						<div class="align-center txt-shadow">
							<div class="icon">
								<i class="fa <?php echo $lonly_options['separator3-icon'] ?> fa-5x"></i>
							</div>
						<span class="color-white"><?php echo $lonly_options['separator3-title'] ?></span>
						</div>
					</div>
					<div class="col-xs-6 col-sm-3 col-md-3">
						<div class="align-center txt-shadow">
							<div class="icon">
								<i class="fa <?php echo $lonly_options['separator4-icon'] ?> fa-5x"></i>
							</div>
						<span class="color-white"><?php echo $lonly_options['separator4-title'] ?></span>
						</div>
					</div>
			</div>		
		</div>
	</section>
	<!-- /Section: separator -->