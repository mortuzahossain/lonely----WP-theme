<?php

function lonly_style_and_scripts() {
	// Styles
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.1.0', 'all'  );
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/font-awesome/css/font-awesome.min.css', array(), '4.2.0', 'all'  );
    wp_enqueue_style( 'nivo-lightbox', get_template_directory_uri() . '/css/nivo-lightbox.css', array(), '1.0', 'all'  );
    wp_enqueue_style( 'nivo-lightbox-theme', get_template_directory_uri() . '/css/nivo-lightbox-theme/default/default.css', array(), '1.0', 'all'  );
    wp_enqueue_style( 'owl.carousel', get_template_directory_uri() . '/css/owl.carousel.css', array(), '1.3.2', 'all'  );
    wp_enqueue_style( 'owl.carousel-theme', get_template_directory_uri() . '/css/owl.theme.css', array(), '1.3.2', 'all'  );
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/css/animate.css', array(), '1.0', 'all'  );
    wp_enqueue_style( 'theme-style', get_template_directory_uri() . '/css/style.css', array(), '1.0', 'all'  );
    wp_enqueue_style( 'default-color', get_template_directory_uri() . '/color/default.css', array(), '1.0', 'all'  );

	//scripts 
    wp_enqueue_script( 'bootstrap.min.js', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '3.1.0', true );
    wp_enqueue_script( 'jquery.easing.min.js', get_template_directory_uri() . '/js/jquery.easing.min.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'jquery.sticky.js', get_template_directory_uri() . '/js/jquery.sticky.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'jquery.scrollTo.js', get_template_directory_uri() . '/js/jquery.scrollTo.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'stellar.js', get_template_directory_uri() . '/js/stellar.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'wow.min.js', get_template_directory_uri() . '/js/wow.min.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'owl.carousel.min.js', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'nivo-lightbox.min.js"', get_template_directory_uri() . '/js/nivo-lightbox.min.js', array('jquery'), '1.0', true );
    wp_enqueue_script( 'custom.js"', get_template_directory_uri() . '/js/custom.js', array('jquery'), '1.0', true );
    
}
add_action( 'wp_enqueue_scripts', 'lonly_style_and_scripts' );






?>