<?php global $lonly_options;?>




	<!-- Section: about -->
    <section id="about" class="home-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					
						<div class="section-heading text-center">
						<div class="wow bounceInDown" data-wow-delay="0.2s">
							<h2><?php echo $lonly_options['about-text-header']; ?></h2>
						</div>
						<p class="wow bounceInUp" data-wow-delay="0.3s"><?php echo $lonly_options['about-text-sub-header']; ?></p>
						</div>
					
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col-md-6">
				
					<img src="
					<?php
		                if ($lonly_options['about-me-img'] && !empty($lonly_options['about-me-img']['url'])) {
		                    echo $lonly_options['about-me-img']['url'];
		                } else {
		                    echo get_template_directory_uri().'/img/img1.jpg';
		                }
		            ?>
					" class="img-responsive img-rounded" alt="" />
				</div>		
				<div class="col-md-6">
					<?php echo $lonly_options['about-text-textarea']; ?>
					<?php 
	                    $layout = $lonly_options['menu-items']['enabled'];
	                    if ($layout): foreach ($layout as $key=>$value) {
                        switch($key) {
                            case 'gallery': echo '<a href="#gallery" class="btn btn-skin btn-lg btn-scroll">See my photos</a>';
                            break;
                        }
                    }
                    endif;
                    ?>
				</div>
			</div>		
		</div>
	</section>
	<!-- /Section: about -->