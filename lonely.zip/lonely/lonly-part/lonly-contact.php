<?php global $lonly_options;?>
<!-- Section: contact -->
    <section id="contact" class="home-section text-center">
        <div class="heading-contact">
            <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-offset-2">
                    
                    <div class="section-heading">
                    <div class="wow bounceInDown" data-wow-delay="0.4s">
                    <h2><?php echo $lonly_options['contact-text-header']; ?></h2>
                    </div>
                    <p class="wow lightSpeedIn" data-wow-delay="0.3s"><?php echo $lonly_options['contact-text-sub-header']; ?></p>
                    </div>
                    
                </div>
            </div>
            </div>
        </div>
        <div class="container">

    <div class="row">
        <div class="col-lg-8 col-md-offset-2">
            <div class="form-wrapper marginbot-50">
                <form id="contact-form" method="POST" action="http://formspree.io/<?php echo $lonly_options['contact-email-send-address']?>">
                <div class="row">
    
                        <div class="form-group">
                            <label for="name">
                                Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="email">
                                Email Address</label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="subject">
                                Subject</label>
                            <select id="subject" name="subject" class="form-control" required="required">
                                <option value="" selected="">Choose One:</option>
                                <?php if( !empty($lonly_options['contact-option selector']) ){
                                    foreach($lonly_options['contact-option selector'] as $single_option):
                                ?>
                                <option value="<?php echo $single_option['title'] ?>"><?php echo $single_option['title']?></option>
                                <?php endforeach; } else{
                                ?>
                                <option value="f-request">Friendship request</option>
                                <option value="mary">Wanna marry you</option>
                                <option value="prom">Prom night invitation</option>
                                <?php } ?>

                            </select>
                        </div>
          
                        <div class="form-group">
                            <label for="name">
                                Message</label>
                            <textarea name="message" id="message" name="message" class="form-control" rows="9" cols="25" required="required"
                                placeholder="Message"></textarea>
                        </div>
       
           
                        <button type="submit" class="btn btn-skin btn-block" id="btnContactUs">
                            Send Message</button>
       
                </div>
                </form>
                
            </div>
            <div class="text-center">
                    <p class="lead"><i class="fa fa-phone"></i> Call me <?php echo $lonly_options['contact-text-cell-number']; ?></p>
            </div>
        </div>

    </div>  

        </div>
    </section>
