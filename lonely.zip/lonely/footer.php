<?php global $lonly_options;?>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<p><?php echo $lonly_options['footer-text']; ?></p>
				</div>
			</div>	
		</div>
	</footer>

    <?php wp_footer(); ?>

</body>

</html>
