<?php

include( get_template_directory() .'/inc/theme-style-js.php'  );

// Redux fremwork 

if (!class_exists("ReduxFrameworkPlugin")) {
	require_once(get_template_directory()."/inc/redux-framework/redux-framework.php");
	require_once(get_template_directory()."/inc/lonly-options.php");
}

// Removing Redux Framework From tools

add_action( 'admin_menu', 'remove_redux_menu',12 );
	function remove_redux_menu() {
	remove_submenu_page('tools.php','redux-about');
}

?>