<?php get_header(); ?>

<?php 
$layout = $lonly_options['menu-items']['enabled'];
if ($layout): foreach ($layout as $key=>$value) {
 
    switch($key) {
        case 'about': get_template_part( 'lonly-part/lonly', 'about' );
        break;
 
        case 'gallery': get_template_part( 'lonly-part/lonly', 'gallery' );;
        break;
 
        case 'contact': get_template_part( 'lonly-part/lonly', 'contact' );; 
        break;

        case 'experiance': get_template_part( 'lonly-part/lonly', 'experiance' );; 
        break;
    }
}
endif;
?>




<?php get_footer(); ?>