<?php global $lonly_options;?>

<!-- Section: gallery -->
    <section id="gallery" class="home-section text-center bg-gray">

			<div class="container">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow bounceInDown" data-wow-delay="0.4s">
					<div class="section-heading">
						<h2><?php echo $lonly_options['gallery-text-header']; ?></h2>
						<p><?php echo $lonly_options['gallery-text-sub-header']; ?></p>
					</div>
					</div>
				</div>
			</div>
			</div>

		<div class="container">
			<div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12" >
					<div class="wow bounceInUp" data-wow-delay="0.4s">
                    <div id="owl-works" class="owl-carousel">
                        

						<?php if( !empty($lonly_options['all-gallery-images']) ){
							foreach($lonly_options['all-gallery-images'] as $single_images):
						?>
							
						<div class="item">
                        	<a href="<?php echo $single_images['image']?>" title="<?php echo $single_images['title']; ?>" data-lightbox-gallery="gallery1">
                        		<img src="<?php echo $single_images['image']?>" class="img-responsive" alt="img">
                        	</a>
                        </div>

						<?php endforeach; } else{
						?>
						<div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/1.jpg" class="img-responsive" alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/2.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/2.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/3.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/3.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/4.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/4.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/5.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/5.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/6.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/6.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/7.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/7.jpg" class="img-responsive " alt="img"></a></div>
                        <div class="item"><a href="<?php echo get_template_directory_uri(); ?>/img/gallery/8.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><img src="<?php echo get_template_directory_uri(); ?>/img/gallery/8.jpg" class="img-responsive " alt="img"></a></div>
                        <?php } ?>

                    </div>
					</div>
                </div>
            </div>
		</div>
	</section>
	<!-- /Section: services -->