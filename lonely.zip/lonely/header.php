<?php global $lonly_options;
?>


<!DOCTYPE html>
<html lang="<?php bloginfo( 'language' ); ?>">

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php bloginfo( 'description' ); ?>">
    <meta name="author" content="Md Mortuza Hossain">

    <title><?php bloginfo( 'name' );echo " || "; bloginfo( 'description' ); ?></title>

    <!-- CSS -->
	<?php wp_head(); ?>

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom" <?php body_class( '' ); ?>>
	<!-- Preloader -->
	<div id="preloader">
	  <div id="load"></div>
	</div>

	<!-- Section: intro -->
    <section id="intro" class="intro" style="background: url(<?php if($lonly_options['banner-img'] && !empty($lonly_options['banner-img']['url'])){echo $lonly_options['banner-img']['url'];}else{echo get_template_directory_uri().'/img/bg1.jpg';} ?>) no-repeat top center;">
	
		<div class="slogan">
			<a href="index.html"><img src="
            <?php
                if ($lonly_options['banner-logo'] && !empty($lonly_options['banner-logo']['url'])) {
                    echo $lonly_options['banner-logo']['url'];
                } else {
                    echo get_template_directory_uri().'/img/logo.png';
                }
            ?>
            " alt="" /></a>
		</div>

		<div class="page-scroll">
			<a href="#about">
				<i class="fa fa-angle-down fa-5x animated"></i>
			</a>
		</div>
    </section>
	<!-- /Section: intro -->




	
    <!-- Navigation -->
    <div id="navigation">
        <nav class="navbar navbar-custom" role="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    	<!-- Brand and toggle get grouped for better mobile display -->
                    	<div class="navbar-header">
                    	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
                    	      <i class="fa fa-bars"></i>
                    	      </button>
                    	</div>
                    	<!-- Collect the nav links, forms, and other content for toggling -->
                    	<div class="collapse navbar-collapse" id="menu">

                    	    <ul class="nav navbar-nav">
                                <?php 
                                $layout = $lonly_options['menu-items']['enabled'];
                                if ($layout): foreach ($layout as $key=>$value) {
                                 
                                    switch($key) {
                                 
                                        case 'home': echo '<li><a href="#intro">Home</a></li>';
                                        break;
                                 
                                        case 'about': echo '<li><a href="#about">About Me</a></li>';
                                        break;
                                 
                                        case 'gallery': echo '<li><a href="#gallery">My gallery</a></li>';
                                        break;
                                 
                                        case 'contact': echo '<li><a href="#contact">Talk to me</a></li>'; 
                                        break;

                                        case 'experiance': echo '<li><a href="#separator">Separator</a></li>'; 
                                        break;
                                    }
                                }
                                endif;
                                ?>
                    	    </ul>

                    	</div>
                    	<!-- /.Navbar-collapse -->
                    </div>
                </div>
            </div>
            <!-- /.container -->
        </nav>
    </div> 
    <!-- /Navigation -->  


