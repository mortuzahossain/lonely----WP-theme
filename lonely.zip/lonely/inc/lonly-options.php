<?php

    /**
     * ReduxFramework Barebones Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "lonly_options";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Lonly Options', 'redux-framework-demo' ),
        'page_title'           => __( 'Lonly Options', 'redux-framework-demo' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-megaphone',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => false,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => 'dashicons-megaphone',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '_options',
        // Page slug used to denote the panel
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );




    // Add content after the form.
    $args['footer_text'] = __( '<p>This Theme is Developed by <a href="http://www.facebook.com/mdmortuza.hossain/">Md. Mortuza Hossain</a> </p>', 'redux-framework-demo' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */




    // -> START Basic Fields

    Redux::setSection( $opt_name, array(
        'title' => __( 'General Options', 'redux-framework-demo' ),
        'id'    => 'basic',
        'desc'  => __( 'Basic fields as subsections.', 'redux-framework-demo' ),
        'icon'  => 'el el-wrench-alt'
    ) );
    Redux::setSection( $opt_name, array(
        'title'            => __( 'Banner', 'redux-framework-demo' ),
        'id'               => 'banner',
        'subsection'       => true,
        'icon'             => 'el el-flag',
        'fields'           => array(
            array(
                'id'       => 'banner-logo',
                'type'     => 'media',
                'title'    => __( 'Banner Logo', 'redux-framework-demo' ),
                'desc'     => __( 'Upload lagre image as banner to get best view. 236*200 is recomonded to best view', 'redux-framework-demo' ),
                'subtitle' => __( 'Upload any media as banner.', 'redux-framework-demo' ),
            ),
            array(
                'id'       => 'banner-img',
                'type'     => 'media',
                'title'    => __( 'Banner Image', 'redux-framework-demo' ),
                'desc'     => __( 'Upload lagre image as banner to get best view. 236*200 is recomonded to best view', 'redux-framework-demo' ),
                'subtitle' => __( 'Upload any media as banner.', 'redux-framework-demo' ),
            ),
        )
    ));
    Redux::setSection( $opt_name, array(
        'title'            => __( 'CC Text', 'redux-framework-demo' ),
        'id'               => 'footer-bottom',
        'subsection'       => true,
        'icon'             => 'el el-cc',
        'fields'           => array(
            array(
                'id'       => 'footer-text',
                'type'     => 'text',
                'title'    => __('Footer Copyright Text', 'redux-framework-demo'),
                'default'  => '&copy;Copyright 2014 . Alice Lonely . design by <a href="http://bootstraptaste.co">Bootstrap Themes</a>'
            ),
        )
    ));




    // Main Navigation and area shorting area

    Redux::setSection( $opt_name, array(
        'title' => __( 'Navigation', 'redux-framework-demo' ),
        'id'    => 'header',
        'icon'  => 'el el-lines',
        'fields'     => array(
            array(
                'id'      => 'menu-items',
                'type'    => 'sorter',
                'options' => array(
                    'enabled'  => array(
                        'home' => 'Home',
                        'about' => 'About',
                        'experiance'   => 'Experiance',
                        'gallery' => 'Gallery',
                        'contact'     => 'Contact',
                    ),
                    'disabled' => array(
                    )
                ),
            ),
        )
    ) );



    // Seperator Or Experiance area

    Redux::setSection( $opt_name, array(
        'title' => __( 'Separator', 'redux-framework-demo' ),
        'id'    => 'separator-area',
        'desc'  => __( 'You can get all the post icon from <a href="http://fontawesome.io/icons/">here</a> .', 'redux-framework-demo' ),
        'icon'  => 'el el-asl',
        'fields'     => array(
            array(
                'id'       => 'separator-parallax-img',
                'type'     => 'media',
                'title'    => __( 'Background Image', 'redux-framework-demo' ),
                'desc'     => __( 'Upload large image as banner to get best view. 2000*800 is recommended to best view', 'redux-framework-demo' ),
            ),


             array(
                'id'     => 'section-end-1',
                'type'   => 'section',
                'title'    => __( 'Separator Post 1', 'redux-framework-demo' ),
                'indent' => true,
            ),
            array(
                'id'       => 'separator1-title',
                'type'     => 'text',
                'title'    => __('Separator Title', 'redux-framework-demo'),
                'default'  => 'Bachelor of Design'
            ),
            array(
                'id'       => 'separator1-icon',
                'type'     => 'text',
                'title'    => __('Separator Icon', 'redux-framework-demo'),
                'default'  => 'fa-graduation-cap'
            ),


            array(
                'id'     => 'section-end-2',
                'type'   => 'section',
                'title'    => __( 'Separator Post 2', 'redux-framework-demo' ),
                'indent' => true,
            ),
            array(
                'id'       => 'separator2-title',
                'type'     => 'text',
                'title'    => __('Separator Title', 'redux-framework-demo'),
                'default'  => '10x failed in love'
            ),
            array(
                'id'       => 'separator2-icon',
                'type'     => 'text',
                'title'    => __('Separator Icon', 'redux-framework-demo'),
                'default'  => 'fa-heart'
            ),


            array(
                'id'     => 'section-end-3',
                'type'   => 'section',
                'title'    => __( 'Separator Post 3', 'redux-framework-demo' ),
                'indent' => true,
            ),
            array(
                'id'       => 'separator3-title',
                'type'     => 'text',
                'title'    => __('Separator Title', 'redux-framework-demo'),
                'default'  => 'I love traveling'
            ),
            array(
                'id'       => 'separator3-icon',
                'type'     => 'text',
                'title'    => __('Separator Icon', 'redux-framework-demo'),
                'default'  => 'fa-plane'
            ),


            array(
                'id'     => 'section-end-4',
                'type'   => 'section',
                'title'    => __( 'Separator Post 4', 'redux-framework-demo' ),
                'indent' => true,
            ),
            array(
                'id'       => 'separator4-title',
                'type'     => 'text',
                'title'    => __('Separator Title', 'redux-framework-demo'),
                'default'  => 'I\'m photographer'
            ),
            array(
                'id'       => 'separator4-icon',
                'type'     => 'text',
                'title'    => __('Separator Icon', 'redux-framework-demo'),
                'default'  => 'fa-camera'
            ),
        )
    ) );



    // For About Us Section
    Redux::setSection( $opt_name, array(
        'title' => __( 'About', 'redux-framework-demo' ),
        'id'    => 'about-area',
        'desc'  => __( 'By this user can change Your About me Section', 'redux-framework-demo' ),
        'icon'  => 'el el-adult ',
        'fields'     => array(
            array(
                'id'       => 'about-text-header',
                'type'     => 'text',
                'title'    => __('About Me Header Text', 'redux-framework-demo'),
                'default'  => 'My name is Alice'
            ),
            array(
                'id'       => 'about-text-sub-header',
                'type'     => 'text',
                'title'    => __('About Me Sub-Header Text', 'redux-framework-demo'),
                'default'  => 'I\'m 28 years old from a village near Alpen mountain and I\'m a spinster :('
            ),
            array(
                'id'       => 'about-me-img',
                'type'     => 'media',
                'title'    => __( 'About Me Image', 'redux-framework-demo' ),
                'desc'     => __( 'Upload About Me image. To get best view 800*530 is recommended to best view.', 'redux-framework-demo' )
            ),
            array(
                'id'=>'about-text-textarea',
                'type' => 'textarea',
                'title' => __('About Me Text-Area - HTML Validated', 'redux-framework-demo'), 
                'default'  => '<p><strong>You\'ll fall in love with me at the first sight</strong></p>
                    <p>
                    Lorem ipsum dolor sit amet, ei purto tamquam ceteros his, eos in graece posidonium. 
                    Ex nullam vidisse salutatus sed, ea persius phaedrum tincidunt vel. Option virtute nonumes ne est. 
                    Id homero expetendis eam, dictas rationibus ut has.
                    </p>
                    <blockquote>
                    Pri pertinacia elaboraret te, an eirmod delicatissimi nec. Eu liber quodsi maiorum mei. 
                    Civibus perfecto rationibus id his, est noster nostrud aliquando at.
                    </blockquote>'
            ),
        )
    ) );


    // Gallery Section

    Redux::setSection( $opt_name, array(
        'title' => __( 'Gallery', 'redux-framework-demo' ),
        'id'    => 'gallery-area',
        'desc'  => __( 'By this user can change home page image and logo..', 'redux-framework-demo' ),
        'icon'  => 'el el-picture ',
        'fields'     => array(
            array(
                'id'       => 'gallery-text-header',
                'type'     => 'text',
                'title'    => __('Gallery Header Text', 'redux-framework-demo'),
                'default'  => 'My photo gallery'
            ),
            array(
                'id'       => 'gallery-text-sub-header',
                'type'     => 'text',
                'title'    => __('Gallery Sub Header Text', 'redux-framework-demo'),
                'default'  => 'Take a look at my personal moment, enjoy'
            ),
            array(
                'id'          => 'all-gallery-images',
                'type'        => 'slides',
                'title'    => __('All Gallery Images', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Image Title: (This is an image title)', 'redux-framework-demo'),
                    'description'             => __('No need to fill', 'redux-framework-demo'),
                    'url'     => __('No need to fill', 'redux-framework-demo'),
                ),
            ),
        )
    ) );

    // For Contact Area
    Redux::setSection( $opt_name, array(
        'title' => __( 'Contact', 'redux-framework-demo' ),
        'id'    => 'contact-area',
        'icon'  => 'el el-address-book',
        'fields'     => array(
            array(
                'id'       => 'contact-text-header',
                'type'     => 'text',
                'title'    => __('Contact Header Text', 'redux-framework-demo'),
                'default'  => 'Email or phone are welcome'
            ),
            array(
                'id'       => 'contact-text-sub-header',
                'type'     => 'text',
                'title'    => __('Contact Sub Header Text', 'redux-framework-demo'),
                'default'  => 'Gentleman, introduce your self and get in touch with me privately'
            ),
            array(
                'id'       => 'contact-text-cell-number',
                'type'     => 'text',
                'title'    => __('Contact Sub Header Text', 'redux-framework-demo'),
                'default'  => '+1 888 9796 88'
            ),
            array(
                'id'       => 'contact-email-send-address',
                'type'     => 'text',
                'title'    => __('Email Address: (Where you want to receive)', 'redux-framework-demo'),
                'default'  => 'demo@gmail.com'
            ),
            array(
                'id'          => 'contact-option selector',
                'type'        => 'slides',
                'title'    => __('Contact Subject Options', 'redux-framework-demo'),
                'desc'     => __( 'Only fill the subject field during new subject.', 'redux-framework-demo' ),
                'placeholder' => array(
                    'title'           => __('Subject: (Friendship request)', 'redux-framework-demo'),
                    'description'             => __('No need to fill', 'redux-framework-demo'),
                    'url'     => __('No need to fill', 'redux-framework-demo'),
                ),
            ),
        )
    ) );